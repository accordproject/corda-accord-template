# Promissory Note

This contract specifies how an interest bearing loan should be repaid.
